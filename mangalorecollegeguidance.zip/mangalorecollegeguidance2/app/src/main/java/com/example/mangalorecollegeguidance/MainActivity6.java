package com.example.mangalorecollegeguidance;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity6 extends AppCompatActivity {
    Button unity,global,sharau,karunya,sri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        unity= findViewById(R.id.unity);
        global=findViewById(R.id.global);
        sharau=findViewById(R.id.sharau);
        karunya=findViewById(R.id.karunya);
        sri=findViewById(R.id.sri);

        unity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.sulekha.com/ambulance-services/mangalore";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        global.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.manipalhospitals.com/mangalore/mars/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        sharau.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://www.ajhospital.in/facility/icu-ambulance-service";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        karunya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://scshospital.org/emergency/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        sri.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://medintu.in/ambulance-services-in-mangalore/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
    }
}