package com.example.mangalorecollegeguidance;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity5 extends AppCompatActivity {
    Button alvas,bharati,aarogya;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);
        alvas= findViewById(R.id.alvas);
        bharati=findViewById(R.id.bharati);
        aarogya=findViewById(R.id.aarogya);
        alvas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://alvashealthcentre.com/services";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        bharati.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://yellowpages.webindia123.com/d-t/Karnataka/Mangalore/Ganesh-Ambulance-Hampankatta/8351/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });
        aarogya.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String url="https://yellowpages.webindia123.com/d-t/Karnataka/Mangalore/St-Joseph-Ambulance-Service/7797/";
                Intent intent=new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(url));
                startActivity(intent);

            }
        });

    }
}